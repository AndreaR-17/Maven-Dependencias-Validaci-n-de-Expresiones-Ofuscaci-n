package stackHandler.handler;

import java.util.ArrayDeque;
import java.util.Deque;

public class Main {

    public static void main(String[] args) {

        if (args.length == 0) {
            System.out.println("Debe enviar una expresion como argumento");
            return;
        }

        // Construir la expresión con for (por si la pasan con espacios)
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            sb.append(args[i]);
            if (i < args.length - 1) {
                sb.append(' ');
            }
        }
        String expresion = sb.toString();

        boolean resultado = isBalancedWithFor(expresion);
        System.out.println(resultado ? "True" : "False");
    }

    /**
     * Valida balance de (), {}, [] usando for y una pila.
     */
    private static boolean isBalancedWithFor(String s) {
        Deque<Character> stack = new ArrayDeque<>();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);

            // Abridores
            if (c == '(' || c == '{' || c == '[') {
                stack.push(c);
                continue;
            }

            // Cerradores
            if (c == ')' || c == '}' || c == ']') {
                if (stack.isEmpty()) return false;
                char top = stack.pop();
                if (!match(top, c)) return false;
            }
            // Otros caracteres se ignoran
        }

        return stack.isEmpty();
    }

    private static boolean match(char open, char close) {
        return (open == '(' && close == ')')
            || (open == '{' && close == '}')
            || (open == '[' && close == ']');
    }
}

