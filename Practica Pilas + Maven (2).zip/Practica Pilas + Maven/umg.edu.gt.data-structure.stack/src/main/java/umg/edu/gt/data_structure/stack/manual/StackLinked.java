package umg.edu.gt.data_structure.stack.manual;

public class StackLinked {

    private Node top; // tope de la pila

    // Verifica si la pila está vacía
    public boolean isEmpty() {
        return top == null;
    }

    // Inicializa la pila con el primer elemento
    public void initStack(char value) {
        top = new Node(value, null, 0);
    }

    // Inserta un nuevo elemento en la pila
    public void push(char value) {
        if (isEmpty()) {
            initStack(value);
        } else {
            top = new Node(value, top, top.count);
        }
    }

    // Devuelve el tamaño de la pila
    public int size() {
        if (isEmpty()) {
            return 0;
        }
        return top.count;
    }

    // Devuelve el nodo inicial (tope actual)
    public Node getNodeInit() {
        return top;
    }

    // Elimina y devuelve el elemento superior
    public char pop() {
        if (isEmpty()) {
            return '0'; // evita excepción, comportamiento controlado
        }
        char value = top.value;
        top = top.next;
        return value;
    }

    // Devuelve el elemento superior sin eliminarlo
    public char peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack underflow");
        }
        return top.value;
    }
}